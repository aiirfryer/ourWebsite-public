# **Greatsword V3**
-------

<img width="960" alt="image" src="https://github.com/JustTacoJohn/Greatsword/assets/119009502/f0e1b322-9432-49bf-921f-231c2cfecbc9">

-------

<img width="960" alt="image" src="https://github.com/JustTacoJohn/Greatsword-V3/assets/119009502/26cbe91f-a5f6-4d71-86d9-0ecc3c5d81d0">


-------

This says 97% html because of the gfiles Lmao

Only deploy this with CodeSandbox and/or Render.

The official link ***is*** going to be slow

# What is Greatsword?
A stupid project made by a dumb kid in middle school.
<br>
This is the sequel to GreatSword v2. Greatsword was an unblocker I made, but it had very outdated scripts and styles compared to new tech. 
<br>
I made this repo to hopefully modernize Greatsword, and keep its feel.
<br>
Please star if you enjoy, it helps this repo grow.

# Important
In order to use "unsafe" Greatsword V2 links you must put your pointer in the middle of the "deceptive site" screen, and type "thisisunsafe". This may redirect you to a new tab, or something else. You may have to go back to the same site and repeat this process up to 10 times. Eventually it will become usable.

# Current bugs:
* Chrome safe browsing may falsely flag links.
* If this happens, about:blank cloak reports as "unsafe" and typing "thisisunsafe" does not work.
* Greatsword ***may*** be broken in chrome on windows devices.
# Links:
Discord: https://discord.gg/BMxe6D9CKv

New links ***are*** added to the discord every day.

Credit to this [Gigachad](https://github.com/dragon731012/) for DM Unblocker.

# Other Credits
Orphanlol - Modifying the README (Three times)
<br>
Tacogamerman - Creator of Gsv2
<br>
Skool - Creator of skooleagler
<br>
Cosmosthedev - Provider of an eaglercraft client folder
<br>
I1aw - Provider of Gfiles





