// definitely not code from chatgpt
const submitBtn = document.getElementById("submitBtn"); // self explanatory
const passwordField = document.getElementById("password"); // i forgot
const message = document.getElementById("message"); //getting id of the p thing class i forgot what i was called probably to change the text to tell u if u got it right or wrong

const correctPassword = "idk69420"; // the password

submitBtn.addEventListener("click", checkPassword); // waits for user to click on button to run the checkPassword function probably

function checkPassword() {
  const userPassword = passwordField.value;

  if (userPassword === correctPassword) {
    window.location.href = "mp.html"
  } else {
    message.textContent = "incorrect";
  }
}


/*
password = "example"

user = input("enter password: ")

if user == password: 
    print("correct")

    else:
        print("incorrect")
*/